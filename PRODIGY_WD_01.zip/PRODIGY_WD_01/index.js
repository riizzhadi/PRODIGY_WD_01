function scrollValue() {
    var navbar = document.getElementById('navbar');
    var scroll = window.scrollY;
    if (scroll < 200) {
        navbar.classList.remove('BgColour');
        document.body.classList.remove('scrolled');
    } else {
        navbar.classList.add('BgColour');
        document.body.classList.add('scrolled');
    }
}

window.addEventListener('scroll', scrollValue);
